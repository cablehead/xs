#[doc(hidden)]
#[deprecated(note = "\
    #[bon::builder] on top of a struct is deprecated; \
    use `#[derive(bon::Builder)]` instead; \
    see more details at https://elastio.github.io/bon/blog/bon-builder-v2-2-release#derive-builder-syntax-for-structs")]
pub mod builder_attribute_on_a_struct {}
