/*!
Vector algorithms for the `aarch64` target.
*/

pub mod neon;

pub(crate) mod memchr;
