/*!
Vector algorithms for the `wasm32` target.
*/

pub mod simd128;

pub(crate) mod memchr;
