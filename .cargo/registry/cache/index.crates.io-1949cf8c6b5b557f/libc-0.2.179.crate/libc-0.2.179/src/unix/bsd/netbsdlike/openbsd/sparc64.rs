#[doc(hidden)]
pub const _ALIGNBYTES: usize = 0xf;

pub const _MAX_PAGE_SHIFT: u32 = 13;
