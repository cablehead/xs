//! Interfaces common in FreeBSD-derived operating systems. This includes FreeBSD and DragonFlyBSD.
