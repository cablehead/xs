//! System headers (`sys/*`)

pub(crate) mod stat;
pub(crate) mod types;
