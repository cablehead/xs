//! Hermit kernel libc.
//!
//! * Headers: <https://github.com/hermit-os/hermit-rs/tree/main/hermit-abi>
