//! Source directory: `sysdeps/nptl/`o
//!
//! Native POSIX threading library.
//!
//! <https://github.com/bminor/glibc/tree/master/sysdeps/nptl>

pub(crate) mod pthread;
