//! RTEMS libc.
// FIXME(rtems): link to headers needed.
