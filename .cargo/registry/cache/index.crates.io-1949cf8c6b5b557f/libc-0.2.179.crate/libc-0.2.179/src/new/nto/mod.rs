//! QNX Neutrino libc.
// FIXME(nto): link to manpages needed.

pub(crate) mod unistd;
