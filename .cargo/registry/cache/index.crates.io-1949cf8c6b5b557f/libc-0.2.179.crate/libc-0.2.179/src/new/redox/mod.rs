//! Redox libc.
//!
//! * Headers: <https://gitlab.redox-os.org/redox-os/relibc>
