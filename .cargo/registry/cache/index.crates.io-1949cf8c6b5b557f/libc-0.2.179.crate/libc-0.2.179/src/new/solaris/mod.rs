//! Solaris libc.
//!
//! * Manual pages: <https://docs.oracle.com/cd/E36784_01/> (under "Reference Manuals")

pub(crate) mod unistd;
