//! Kyoto Microcomputer SOLID.
// FIXME(solid): link to headers needed.
