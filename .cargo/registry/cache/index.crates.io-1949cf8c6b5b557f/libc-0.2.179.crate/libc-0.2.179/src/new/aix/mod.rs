//! IBM AIX libc.
//!
//! * Headers are not public
//! * Manual pages: <https://www.ibm.com/docs/en/aix> (under "Technical reference" for that version)

pub(crate) mod unistd;
