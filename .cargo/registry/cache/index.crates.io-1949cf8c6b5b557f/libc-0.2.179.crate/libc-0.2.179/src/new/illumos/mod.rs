//! Illumos libc.
// FIXME(illumos): link to headers needed.

pub(crate) mod unistd;
