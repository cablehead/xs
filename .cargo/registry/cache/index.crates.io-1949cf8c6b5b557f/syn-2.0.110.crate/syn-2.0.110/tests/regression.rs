#![allow(clippy::let_underscore_untyped, clippy::uninlined_format_args)]

mod regression {
    automod::dir!("tests/regression");
}
