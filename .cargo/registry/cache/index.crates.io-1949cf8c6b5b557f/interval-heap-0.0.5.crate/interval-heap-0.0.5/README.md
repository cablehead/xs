A double-ended priority queue implemented with an interval heap.

Documentation is available at https://contain-rs.github.io/interval-heap/interval_heap.
