#[derive(derive_more::TryFrom)]
#[repr(a + b)]
enum Enum {
    Variant
}

fn main() {}
