#[derive(derive_more::Display)]
#[display("Stuff({_1})")]
pub struct Foo(String);

fn main() {}
