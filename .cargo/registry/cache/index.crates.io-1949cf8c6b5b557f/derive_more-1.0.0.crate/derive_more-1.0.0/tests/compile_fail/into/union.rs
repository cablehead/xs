#[derive(derive_more::Into)]
pub union Foo {
    bar: i32,
}

fn main() {}
