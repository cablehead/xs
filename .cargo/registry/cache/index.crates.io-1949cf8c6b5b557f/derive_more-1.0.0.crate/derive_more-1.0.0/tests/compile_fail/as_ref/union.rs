#[derive(derive_more::AsRef)]
union Foo {
    f1: u32,
    f2: f32,
}

fn main() {}
