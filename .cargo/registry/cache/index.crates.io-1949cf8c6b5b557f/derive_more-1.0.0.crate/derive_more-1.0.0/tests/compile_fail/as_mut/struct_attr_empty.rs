#[derive(derive_more::AsMut)]
#[as_mut(forward)]
struct Foo;

fn main() {}
