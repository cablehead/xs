#[derive(derive_more::AddAssign)]
union IntOrFloat {
    i: u32,
}

fn main() {}
