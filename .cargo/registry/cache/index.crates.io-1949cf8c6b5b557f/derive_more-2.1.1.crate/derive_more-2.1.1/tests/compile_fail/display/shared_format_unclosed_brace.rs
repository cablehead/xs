#[derive(derive_more::Display)]
#[display("Stuff({)")]
enum Foo {
    A,
}

fn main() {}
