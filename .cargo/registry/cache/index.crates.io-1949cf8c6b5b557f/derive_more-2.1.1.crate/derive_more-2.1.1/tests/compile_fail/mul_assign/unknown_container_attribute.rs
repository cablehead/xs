#[derive(derive_more::MulAssign)]
#[mul_assign(unknown)]
struct Foo( i32);

fn main() {}
