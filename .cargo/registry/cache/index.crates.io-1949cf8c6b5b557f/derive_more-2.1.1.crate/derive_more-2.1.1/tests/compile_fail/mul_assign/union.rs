#[derive(derive_more::MulAssign)]
union IntOrFloat {
    i: u32,
}

fn main() {}
