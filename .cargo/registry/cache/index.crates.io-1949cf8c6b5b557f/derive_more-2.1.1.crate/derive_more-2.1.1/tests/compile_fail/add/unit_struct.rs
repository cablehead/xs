#[derive(derive_more::Add)]
struct Foo;

fn main() {}
