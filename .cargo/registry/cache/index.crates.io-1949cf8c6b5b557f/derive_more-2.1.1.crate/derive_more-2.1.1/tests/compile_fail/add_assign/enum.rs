#[derive(derive_more::AddAssign)]
enum Foo {
    Bar(i32),
}

fn main() {}
