#[derive(derive_more::FromStr)]
pub struct Foo {
    foo: i32,
    bar: i32,
}

fn main() {}
