#[derive(derive_more::Display)]
#[display(rename_all = "Whatever")]
enum Enum {
    UnitVariant,
}

fn main() {}
