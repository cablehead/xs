#[derive(derive_more::AsMut)]
enum Foo {
    Bar(i32),
    Baz(i32),
}

fn main() {}
