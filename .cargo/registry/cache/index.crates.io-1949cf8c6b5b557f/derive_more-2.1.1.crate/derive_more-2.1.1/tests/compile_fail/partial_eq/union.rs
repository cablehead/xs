#[derive(derive_more::PartialEq)]
union IntOrFloat {
    i: u32,
}

fn main() {}
