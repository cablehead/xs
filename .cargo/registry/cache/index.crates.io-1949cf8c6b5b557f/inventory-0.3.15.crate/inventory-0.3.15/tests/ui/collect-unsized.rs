pub struct Unsized(str);

inventory::collect!(Unsized);

fn main() {}
