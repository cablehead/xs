 * Only tc has unparsed `Vec<u8>` left.
 * Still has many flags not converted into `Vec<enum>`.
 * Many place holders in `link::InfoData`.
 * Missing unit test cases.
