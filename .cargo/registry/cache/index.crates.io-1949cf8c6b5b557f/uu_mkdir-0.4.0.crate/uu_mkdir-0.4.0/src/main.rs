uucore::bin!(uu_mkdir);
