#[doc(hidden)]
pub use crate::custom::{ref_cast_custom, CurrentCrate, RefCastCustom};
#[doc(hidden)]
pub use crate::layout::{assert_layout, Layout, LayoutUnsized};
#[doc(hidden)]
pub use crate::trivial::assert_trivial;
#[doc(hidden)]
pub use core::mem::transmute;
