# ureq-proto

Supporting crate for [ureq](https://crates.io/crates/ureq).

This crate contains types used to implement ureq.



License: MIT OR Apache-2.0
