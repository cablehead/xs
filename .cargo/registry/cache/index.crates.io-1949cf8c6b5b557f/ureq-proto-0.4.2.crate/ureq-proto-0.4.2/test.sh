#!/bin/sh

cargo +1.67 test
