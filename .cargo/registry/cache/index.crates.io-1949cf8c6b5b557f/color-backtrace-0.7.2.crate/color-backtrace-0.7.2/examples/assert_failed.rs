fn main() {
    color_backtrace::install();
    assert_eq!(1, 2);
}
