## 0.6.0
19-Feb-2023
* `::print_positions()` iterator now returns just start/end offsets (which is all most apps actually need).
* the former `::print_positions()` function (and supporting items) now renamed to `::print_position_data`.  
This is the one that returns data.
* More, more better documentation and examples.
## 0.5.1, 0.5.2
18-Feb-2023
* Include ANSI OSC escape sequences in the print position slice.
* More better documentation and examples.

## 0.5.0
12-Feb-2023
* Initial release