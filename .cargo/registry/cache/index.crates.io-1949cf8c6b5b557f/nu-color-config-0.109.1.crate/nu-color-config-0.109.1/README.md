Logic to resolve colors for syntax highlighting and output formatting

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
