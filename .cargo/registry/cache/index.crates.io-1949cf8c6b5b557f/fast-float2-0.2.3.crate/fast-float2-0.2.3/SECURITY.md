# Security Policy

This crate is in maintenance mode, so only the latest version is supported and will be receiving bug fixes. If you have a security vulnerability, please reach out to me privately at [ahuszagh@gmail.com](mailto:ahuszagh@gmail.com). Other forms of communication may not reach me.
