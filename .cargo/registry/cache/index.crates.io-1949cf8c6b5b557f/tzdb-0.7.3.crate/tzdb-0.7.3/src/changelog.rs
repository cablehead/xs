#![doc(cfg(any()))]
#![doc = include_str!("../CHANGELOG.md")]
