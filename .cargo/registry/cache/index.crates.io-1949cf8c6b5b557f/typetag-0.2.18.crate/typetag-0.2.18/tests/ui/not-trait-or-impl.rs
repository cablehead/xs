#[typetag::serde]
const HUH: () = ();

fn main() {}
