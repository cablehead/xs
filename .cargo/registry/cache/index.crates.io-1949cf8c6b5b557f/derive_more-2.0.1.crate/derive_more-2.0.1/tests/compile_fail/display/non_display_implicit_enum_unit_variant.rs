#[derive(derive_more::Display, derive_more::UpperHex)]
enum Enum {
    UnitVariant,
}

fn main() {}
