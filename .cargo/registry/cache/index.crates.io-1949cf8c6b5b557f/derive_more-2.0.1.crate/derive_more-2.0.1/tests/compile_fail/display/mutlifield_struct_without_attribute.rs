#[derive(derive_more::Display)]
pub struct Foo {
    foo: String,
    bar: String,
}

fn main() {}
