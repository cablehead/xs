#[derive(derive_more::TryFrom)]
struct Struct;

fn main() {}
