//! This module contains macro functions for dynamic [`Table`] construction.
//!
//! [`Table`]: crate::Table

mod col;
mod row;
