pub use papergrid::config::spanned::{EntityMap, SpannedConfig};
