//! A module for iterator structures.

mod layout_iterator;

pub use layout_iterator::LayoutIterator;
