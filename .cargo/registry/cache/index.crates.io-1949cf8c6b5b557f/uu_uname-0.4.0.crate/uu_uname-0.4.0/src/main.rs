uucore::bin!(uu_uname);
