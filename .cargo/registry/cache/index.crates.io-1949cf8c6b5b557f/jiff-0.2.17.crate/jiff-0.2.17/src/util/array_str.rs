// Re-exported here for convenience.
//
// It used to be defined in this module, but moved to `shared` so that it could
// be used in the POSIX time zone parser.
pub(crate) use crate::shared::util::array_str::*;
