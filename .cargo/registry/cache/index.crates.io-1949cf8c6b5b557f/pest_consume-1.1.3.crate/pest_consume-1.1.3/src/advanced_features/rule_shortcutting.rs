//! # Rule shortcutting
//!
//! TODO
//!
