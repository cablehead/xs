pub const FLAG_CASEI: u32 = 1;
pub const FLAG_MULTI: u32 = 1 << 1;
pub const FLAG_DOTNL: u32 = 1 << 2;
pub const FLAG_SWAP_GREED: u32 = 1 << 3;
pub const FLAG_IGNORE_SPACE: u32 = 1 << 4;
pub const FLAG_UNICODE: u32 = 1 << 5;
