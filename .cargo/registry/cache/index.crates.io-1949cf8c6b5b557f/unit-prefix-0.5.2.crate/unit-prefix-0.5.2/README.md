# unit-prefix

This project is a fork / continuation of the unmaintained
[number_prefix](https://crates.io/crates/number_prefix) crate.

The minimum supported Rust version is currently 1.31 (matching the release of
the 2018 edition).

API documentation and usage examples are available on
[docs.rs](https://docs.rs/unit-prefix).
