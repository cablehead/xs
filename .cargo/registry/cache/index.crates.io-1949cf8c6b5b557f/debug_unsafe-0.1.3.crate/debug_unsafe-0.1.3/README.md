# Debug Unsafe (Rust)

[![Crate](https://img.shields.io/crates/v/debug_unsafe.svg)](https://crates.io/crates/debug_unsafe)
[![API](https://docs.rs/debug_unsafe/badge.svg)](https://docs.rs/debug_unsafe)

For tests to trigger panic instead of UB in unsafe calls.
