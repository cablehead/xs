Utilities used by the different `nu-command`/`nu-cmd-*` crates, should not contain any full `Command` implementations.

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
