# Version 0.1.3

- Remove dependency on `cfg-if`. (#1072)

# Version 0.1.2

- Bump the minimum supported Rust version to 1.61. (#1037)
- Add `compare_insert`. (#976)
- Improve support for targets without atomic CAS. (#1037)
- Remove build script. (#1037)
- Remove dependency on `scopeguard`. (#1045)

# Version 0.1.1

- Fix `get_unchecked` panic by raw pointer calculation. (#940)

# Version 0.1.0

**Note:** This release has been yanked due to bug fixed in 0.1.1.

- Initial implementation.
