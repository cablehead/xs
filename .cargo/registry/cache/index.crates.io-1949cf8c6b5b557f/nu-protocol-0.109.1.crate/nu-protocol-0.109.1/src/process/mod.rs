//! Handling of external subprocesses
mod child;

pub use child::*;
