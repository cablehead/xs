//! Primitives for task wakeup.

pub use crate::{DiatomicWaker, WaitUntil};
