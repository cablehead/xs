# signal-hook-registry

[![Actions Status](https://github.com/vorner/signal-hook/actions/workflows/test.yaml/badge.svg)](https://github.com/vorner/signal-hook/actions)

This is the backend crate for the
[signal-hook](https://crates.io/crates/signal-hook) crate. The general direct
use of this crate is discouraged. See the
[documentation](https://docs.rs/signal-hook-registry) for further details.

## License

Licensed under either of

 * Apache License, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or
   https://www.apache.org/licenses/LICENSE-2.0)
 * MIT license ([LICENSE-MIT](LICENSE-MIT) or
   https://opensource.org/license/mit)

at your option.

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in the work by you, as defined in the Apache-2.0 license, shall be
dual licensed as above, without any additional terms or conditions.
