# ⚠️ UNSTABLE⚠️
_the public interface of this crate is unstable!_

A pure-rust implementation of [zlib](https://www.zlib.net/manual.html).

For a [zlib](https://www.zlib.net/manual.html) -compatible rust api of this crate, see [`libz-rs-sys`](https://crates.io/crates/libz-rs-sys). For a more high-level interface, use [`flate2`](https://crates.io/crates/flate2).
