#[derive(num_enum::IntoPrimitive)]
enum Numbers {
    Zero,
    One,
}

fn main() {}
