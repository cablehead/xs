# Z32

Zero-dependency MIT licensed implementation [z-base-32](https://philzimmermann.com/docs/human-oriented-base-32-encoding.txt) encoding.
