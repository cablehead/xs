Operating system specific bindings used by Nushell.

Currently primarily wrappers around processes and ways to gather process info from the system

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
