uucore::bin!(uu_mktemp);
