pub const COLUMN_TAG_NAME: &str = "tag";
pub const COLUMN_ATTRS_NAME: &str = "attributes";
pub const COLUMN_CONTENT_NAME: &str = "content";
