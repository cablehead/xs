mod common;
pub mod deep;
pub mod merge_;

pub use deep::MergeDeep;
pub use merge_::Merge;
