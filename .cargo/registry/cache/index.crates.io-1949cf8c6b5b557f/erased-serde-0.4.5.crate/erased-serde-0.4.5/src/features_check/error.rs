"erased-serde requires that either `std` (default) or `alloc` feature is enabled"
