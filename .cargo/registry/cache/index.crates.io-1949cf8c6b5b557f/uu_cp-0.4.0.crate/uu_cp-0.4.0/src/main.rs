uucore::bin!(uu_cp);
