---
name: Missing feature
about: Suggest an idea for reedline
title: ''
labels: enhancement
assignees: ''

---

Let us know about features you really want to see in reedline. 

## References

If the feature you are interested in exists in other shells or terminal editors, please share links to documentation or screenshots to easily communicate the desired behavior!
