Implementation detail of the [typetag] crate.

[typetag]: https://github.com/dtolnay/typetag
