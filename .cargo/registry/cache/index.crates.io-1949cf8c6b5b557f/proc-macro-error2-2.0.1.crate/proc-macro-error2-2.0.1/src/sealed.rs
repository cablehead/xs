pub trait Sealed {}

impl Sealed for crate::Diagnostic {}
