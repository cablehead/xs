use proc_macro_error2::proc_macro_error;

#[proc_macro_error]
fn main() {}
