use test_crate::*;

option_ext!(one, two);

fn main() {}
