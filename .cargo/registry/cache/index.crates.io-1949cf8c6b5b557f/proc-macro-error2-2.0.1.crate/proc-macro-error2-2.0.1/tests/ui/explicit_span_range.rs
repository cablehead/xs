use test_crate::*;

explicit_span_range!(one, two, three, four);

fn main() {}
