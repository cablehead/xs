#[test_crate::multiple_tokens]
type T = ();

fn main() {}
